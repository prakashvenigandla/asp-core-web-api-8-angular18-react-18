import { Routes } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductFormComponent } from './product-form/product-form.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './services/auth.guard';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';

export const routes: Routes = [
  { path: '', component:ProductListComponent,canActivate: [AuthGuard] },
  { path:'product-list',component:ProductListComponent,canActivate: [AuthGuard]},
  { path: 'add', component: ProductFormComponent,canActivate: [AuthGuard] },
  { path: 'edit/:id', component: ProductFormComponent,canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  {path:'test',component:TestComponent}
];
