import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Product } from '../product-list/product';
import { ProductService } from '../services/product-service';

@Component({
  selector: 'app-product-form',
  standalone: true,
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css'],
  imports: [CommonModule, FormsModule]
})
export class ProductFormComponent implements OnInit {
  product: Product = { id: 0, name: '', price: 0 };
  isEdit = false;

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.productService.getProduct(+id).subscribe(data => {
        this.product = data;
      });
    }
  }

  onSubmit(): void {
    if (this.isEdit) {
      this.productService.updateProduct(this.product).subscribe(() => {
        this.router.navigate(['/product-list']);
      });
    } else {
      this.productService.addProduct(this.product).subscribe(() => {
        this.router.navigate(['/product-list']);
      });
    }
  }
}
