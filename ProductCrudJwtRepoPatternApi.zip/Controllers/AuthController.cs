﻿using Microsoft.AspNetCore.Mvc;
using AspCoreJwtDb.Data;
using AspCoreJwtDb.Models;
using AspCoreJwtDb.Services;
using System.Threading.Tasks;

namespace AspCoreJwtDb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ITokenService _tokenService;

        public AuthController(IUnitOfWork unitOfWork, ITokenService tokenService)
        {
            _unitOfWork = unitOfWork;
            _tokenService = tokenService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User login)
        {
            var user = await _unitOfWork.Users.GetUserByEmailAsync(login.Email);

            if (user == null || user.Password != login.Password)
            {
                return Unauthorized();
            }

            var token = _tokenService.GenerateToken(user);

            return Ok(new { token });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            var existingUser = await _unitOfWork.Users.GetUserByEmailAsync(user.Email);
            if (existingUser != null)
            {
                return BadRequest("User already exists.");
            }

            await _unitOfWork.Users.AddAsync(user);
            await _unitOfWork.CompleteAsync();

            var token = _tokenService.GenerateToken(user);

            return Ok(new { token });
        }
    }
}
