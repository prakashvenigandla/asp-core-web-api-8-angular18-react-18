using System;
using System.Threading.Tasks;
using AspCoreJwtDb.Data;

public interface IUnitOfWork : IDisposable
    {
        IProductRepository Products { get; }
        IUserRepository Users { get; }
        Task<int> CompleteAsync();
    }