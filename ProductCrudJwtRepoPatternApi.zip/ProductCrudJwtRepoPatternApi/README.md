#Steps to configure security
## 1) Install the package Microsoft.AspNetCore.Authentication.JwtBearer
## 2) Define Models User, Role
## 3) Update Context to incorporate User and Role and seed sample data of users minimun 2 users
## 4) Create appropriate repositories like IUserRepository and implement in UserRepository
## 5) Configure in appsettings.json the JWT related things like issuer, audience, server secret
## 6) In Program.cs add server for authentication with JWT
## 7) Add Authentication and Authorisation middleware
## 8) Create ITokenService and implement in TokenService
## 9) Create Auth cotroller with appropriate logic to handle token
## 10) Build it 
## 11) Run the app
## 12) Test it with swagger/postman