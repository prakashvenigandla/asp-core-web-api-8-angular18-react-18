using System.Threading.Tasks;
using AspCoreJwtDb.Models;

namespace AspCoreJwtDb.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ProductManagementDbContext _context;
        private IProductRepository _productRepository;
        private IUserRepository _userRepository;

        public UnitOfWork(ProductManagementDbContext context)
        {
            _context = context;
        }

        public IProductRepository Products => _productRepository ??= new ProductRepository(_context);
        public IUserRepository Users => _userRepository ??= new UserRepository(_context);

        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}