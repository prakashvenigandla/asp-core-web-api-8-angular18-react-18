using AspCoreJwtDb.Models;

namespace AspCoreJwtDb.Data
{
    public interface IProductRepository : IRepository<Product>
    {
    }
}

