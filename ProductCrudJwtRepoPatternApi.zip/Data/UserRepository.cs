using Microsoft.EntityFrameworkCore;
using AspCoreJwtDb.Models;
using System.Threading.Tasks;

namespace AspCoreJwtDb.Data
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(ProductManagementDbContext context) : base(context)
        {
        }

        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await _context.Users.SingleOrDefaultAsync(u => u.Email == email);
        }
    }
}