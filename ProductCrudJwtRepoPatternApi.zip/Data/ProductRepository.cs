// ProductRepository.cs
using AspCoreJwtDb.Models;

namespace AspCoreJwtDb.Data
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(ProductManagementDbContext context) : base(context)
        {
        }
    }
}