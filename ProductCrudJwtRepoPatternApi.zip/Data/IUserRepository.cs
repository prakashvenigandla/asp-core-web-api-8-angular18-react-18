// IUserRepository.cs
using AspCoreJwtDb.Models;
using System.Threading.Tasks;

namespace AspCoreJwtDb.Data
{
    public interface IUserRepository : IRepository<User>
    {
        Task<User> GetUserByEmailAsync(string email);
    }
}