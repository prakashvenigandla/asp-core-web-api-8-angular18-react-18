using AspCoreJwtDb.Models;

namespace AspCoreJwtDb.Services
{
    public interface ITokenService
    {
        string GenerateToken(User user);
    }
}
